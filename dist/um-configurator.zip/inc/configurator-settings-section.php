<?php
/**
 * Umzugmeister Konfigurator Settings Section
 *
 * Fields HTML for Section.
 *
 * @package UmConfigurator
 */

?>

<p>Allgemeine Einstellungen</p>
